function logout() {

    localStorage.removeItem("usuariologado");
    window.location = "index.html";
}

function filtrarcontagem(){
        fetch(API+"/contador/" + 
        document.getElementById("txtinicio").value + 
        "/" + document.getElementById("txtfim").value)
                .then(res => res.json())
                .then(res=> montartabelacontagem(res));
    }

    function montartabelacontagem(lista){
            var tabela =
            "<table class='table' border='1' align='center' width='80%' cellspacing='2'>" +
            "<tr>" +
            "<th>Alarme</th>"+
            "<th>Quantidade de alarmes no Período</th>"+
            "</tr>";
    for (cont=0;cont<lista.length;cont+=2){
                tabela+= 
                "<tr>" +
                "<td>" + lista[cont] + "</td>" + 
                "<td>" + lista[cont+1] + "</td></tr>";
            }
    tabela+="</table>";
            document.getElementById("resultadoalarme").innerHTML=tabela;
        } 

        function CriarPDF() {
            var minhaTabela = document.getElementById('resultadoalarme').innerHTML;
            var style = "<style>";
            style = style + "table {width: 100%;font: 20px Calibri;}";
            style = style + "table, th, td {border: solid 1px #DDD; border-collapse: collapse;";
            style = style + "padding: 2px 3px;text-align: center;}";
            style = style + "</style>";
        
            var win = window.open('', '', 'height=700,width=800');
            win.document.write('<html><head>');
            win.document.write('<title> Arquivo em PDF </title>');   
            win.document.write(style);                                     
            win.document.write('</head>');
            win.document.write('<body>');
            win.document.write(minhaTabela);                          
            win.document.write('</body></html>');
            win.document.close();                                            
            win.print();                                                            
        }
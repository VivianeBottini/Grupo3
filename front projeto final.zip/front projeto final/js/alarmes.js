function logout() {
    
    localStorage.removeItem("usuariologado");
    window.location = "index.html";
}
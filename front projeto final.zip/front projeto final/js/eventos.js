function logout() {

    localStorage.removeItem("usuariologado");
    window.location = "index.html";
}

function filtrar() {
    fetch(API + "/data/" +
        document.getElementById("txtinicio").value +
        "/" + document.getElementById("txtfim").value)
        .then(res => res.json())
        .then(res => montartabela(res));
}

function montartabela(lista) {
    var tabela =
        "<table class='table' border='1' align='center' width='80%' cellspacing='2'>" +
        "<tr>" +
        "<th>Data do Evento</th>" +
        "<th>Tipo de Alarme</th>" +
        "<th>Hostname do Equipamento</th>" +
        "</tr>";
    for (cont = 0; cont < lista.length; cont++) {
        tabela +=
            "<tr>" +
            "<td>" + lista[cont].data + "</td>" +
            "<td>" + lista[cont].alarme.descricao + "</td>" +
            "<td>" + lista[cont].equipamento.hostname + "</td></tr>";
    }
    tabela += "</table>";
    document.getElementById("resultadoevt").innerHTML = tabela;
}

function CriarPDF() {
    var minhaTabela = document.getElementById('resultadoevt').innerHTML;
    var style = "<style>";
    style = style + "table {width: 100%;font: 20px Calibri;}";
    style = style + "table, th, td {border: solid 1px #DDD; border-collapse: collapse;";
    style = style + "padding: 2px 3px;text-align: center;}";
    style = style + "</style>";

    var win = window.open('', '', 'height=700,width=800');
    win.document.write('<html><head>');
    win.document.write('<title> Arquivo em PDF </title>');
    win.document.write(style);
    win.document.write('</head>');
    win.document.write('<body>');
    win.document.write(minhaTabela);
    win.document.write('</body></html>');
    win.document.close();
    win.print();
}

function exportar() {
    fetch(API + "/data/" +
        document.getElementById("txtinicio").value +
        "/" + document.getElementById("txtfim").value)
        .then(res => res.json())
        .then(res => gerarCSV(res));
}

function gerarCSV(lista) {

    let relatorio = document.getElementById("resultadoevt");

    if (lista == null || lista.lenght == 0) {
        relatorio.innerHTML = `<p>Nenhum registro encontrado.</p>`;
        return;
    }

    let csv = "";

    lista.forEach(resultado => {
        // csv += `${e.campo1};${e.campo2};${e.campo3};\n`;
        csv += `${resultado.data};${resultado.alarme.descricao};${resultado.equipamento.hostname}\n`;
    });
    let hiddenElement = document.createElement('a');
    hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
    hiddenElement.target = '_blank';
    hiddenElement.download = 'solicitacoes.csv'
    hiddenElement.click();
}


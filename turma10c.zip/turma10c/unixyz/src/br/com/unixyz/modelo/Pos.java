package br.com.unixyz.modelo;

import br.com.unixyz.padroes.PadraoFormacao;

public class Pos implements PadraoFormacao {
	
	private String xpto;

	@Override
	public void calcMensalidade(double fator) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getAll() {
		// TODO Auto-generated method stub
		return null;
	}
	

}//fecha class

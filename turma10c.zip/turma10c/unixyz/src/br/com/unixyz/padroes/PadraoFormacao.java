package br.com.unixyz.padroes;

public interface PadraoFormacao { //Aten�ao: n�o � class e sim interface
	
	void calcMensalidade (double fator);
	String getAll();
	

}//fecha interface

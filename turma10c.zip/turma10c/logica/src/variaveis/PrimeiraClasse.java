package variaveis;

public class PrimeiraClasse {
	// main() � o m�todo StartPoint (m�todo principal)

	public static void main(String[] args) {

		System.out.print("Hello World");

	}
}

package decisao;

import javax.swing.JOptionPane;

public class Exercicio1H {

	public static void main(String[] args) {

		//Um hotel cobra R$ 80,00 a di�ria e mais uma taxa de servi�os
		//A taxa de servi�os � de: 
		//R$ 5,50 por di�ria, se o n�mero de di�rias for maior que 15;
		//R$ 6,00 por di�ria, se o n�mero de di�rias for igual a 15;
		//R$ 8,00 por di�ria, se o n�mero de di�rias for menor que 15.
		//Monte uma aplica��o que apresente a conta do cliente.

		short qtdeDiarias = Short.parseShort(JOptionPane.showInputDialog("Digite a quantidade de di�rias"));
		double valorDiaria=0; 

		if(qtdeDiarias>15) {
			valorDiaria=85.5;
		}else if(qtdeDiarias==15) {
			valorDiaria=86;
		}else {
			valorDiaria=88;
		}
		System.out.println("Total: " + (valorDiaria*qtdeDiarias));

	}//fecha main		
}//fecha class

